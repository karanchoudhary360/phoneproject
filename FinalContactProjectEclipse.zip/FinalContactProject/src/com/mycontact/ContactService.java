package com.mycontact;

import java.util.List;
import javax.ws.rs.Consumes;
//import javax.websocket.server.PathParam;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;



@Path("/contacts")
public class ContactService {
//	ContactDAO cd =new ContactDAO();
	@GET
	@Path("/getContacts")
    @Produces(MediaType.APPLICATION_JSON  )
    public List<Contact> getContacts() {
       
        return ContactDAO.getAllContacts();
    }
 
    // URI:
    // /contextPath/servletPath/employees/{empNo}
    @GET
    @Path("/getContact/{contactName}")
    @Produces( MediaType.APPLICATION_JSON)
    public Contact getContact(@PathParam("contactName") String contactName) {
        return ContactDAO.getContact(contactName);
    }
 
    // URI:
    // /contextPath/servletPath/employees
    @POST
    @Path("/addContact")
    @Consumes( MediaType.APPLICATION_JSON)
    public Contact addContact(Contact con) {
        return ContactDAO.addContact(con);
    }
    // URI:
    // /contextPath/servletPath/employees
    
    @PUT
    @Path("/updateContact")
    @Produces(MediaType.APPLICATION_JSON)
    public Contact updateContact(Contact con) {
        return ContactDAO.updateContact(con);
    }
 
    @DELETE
    @Path("/deleteContact/{contactName}")
    @Produces(MediaType.APPLICATION_JSON)
    public void deleteContact(@PathParam("contactName") String contactName) {
    	ContactDAO.deleteContact(contactName);
    }
}
