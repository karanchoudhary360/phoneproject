package com.mycontact;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Contacts")
public class Contact {

	public Contact() {
		super();
	}
	/**
	 * @param contactNumber
	 * @param contactName
	 */
	public Contact(String contactName, String contactNumber) {
		super();
		this.contactNumber = contactNumber;
		this.contactName = contactName;
	}
	
	

	private String contactNumber;
	private String contactName;	
	
	  public String getContactNumber() {
		return contactNumber;
	}
	  @XmlElement
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getContactName() {
		return contactName;
	}
	@XmlElement
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	
	
}
