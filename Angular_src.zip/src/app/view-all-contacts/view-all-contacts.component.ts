import { Component, OnInit } from '@angular/core';
import {  Subscription } from 'rxjs';
import { ContactService } from '../contact.service';
import {Contact} from '../Contact';


@Component({
  selector: 'app-view-all-contacts',
  templateUrl: './view-all-contacts.component.html',
  styleUrls: ['./view-all-contacts.component.css']
})
export class ViewAllContactsComponent  {
  contName: string="";

  conts: Contact[];
  tempConts: Contact[];
  cont:Contact =new Contact();
  private subscription: Subscription;
  constructor(private contService: ContactService) { }
    
    
    ngOnInit(){
      this.subscription =this.contService.fetchAllContacts().subscribe((data:Contact[])=>{
        this.conts = data;
        this.tempConts = data;
      },(err) =>{
        console.log(err);
      
    });
    }

    deleteContact(c: string){
      // console.log('Contact name searched '+c);
      this.contService.deleteContact(c).subscribe((data:Contact) => {
        if(data==null){
          this.tempConts=this.conts.filter(d => (d.contactName != c) );
          this.conts = this.tempConts;
          console.log('Record deleted '+c);
        }
      }, (err)=>{
        console.log(err);
      });
    }
    


viewContact() {
  if(this.contName == null)  {
    console.log('its null : '+this.contName);
    this.tempConts = this.conts;
  }
  else {
    console.log('its not zero : '+this.contName);
    this.tempConts = this.conts.filter(d => (d.contactName == this.contName) );
    
    console.log('tempConts length : '+this.tempConts.length);
    console.log('conts length : '+this.conts.length);
    

  }
}
  modifyContact() {
    
    this.contService.modifyContact(this.cont).subscribe(data => {
     
     // alert(JSON.stringify(data));
    })
  }

}
