import { Component, OnInit } from '@angular/core';
import { Contact } from '../Contact';
import { ContactService } from '../contact.service';

@Component({
  selector: 'app-add-contact',
  templateUrl: './add-contact.component.html',
  styleUrls: ['./add-contact.component.css']
})
export class AddContactComponent implements OnInit {

  cont:Contact =new Contact();
  constructor(private service: ContactService) { 
    this.cont.contactName='';
    this.cont.contactNumber='';
  }

 
  ngOnInit(): void {}
  
  addContact() {
    this.service.addAContact(this.cont).subscribe(data => {
      alert(JSON.stringify(data));
    })
  }
}
