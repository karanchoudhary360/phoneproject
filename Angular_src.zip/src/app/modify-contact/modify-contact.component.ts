import { Component, OnInit } from '@angular/core';
import { Contact } from '../Contact';
import { ContactService } from '../contact.service';

@Component({
  selector: 'app-modify-contact',
  templateUrl: './modify-contact.component.html',
  styleUrls: ['./modify-contact.component.css']
})
export class ModifyContactComponent implements OnInit {

  cont:Contact =new Contact();
  constructor(private service: ContactService) { 
    this.cont.contactName='';
    this.cont.contactNumber='';
  }

  ngOnInit(): void {
  }
  modifyContact() {
    
    this.service.modifyContact(this.cont).subscribe(data => {
     
     // alert(JSON.stringify(data));
    })
  }
  }
