import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {  Observable } from 'rxjs';
import {Contact} from './Contact';

@Injectable({
  providedIn: 'root'
})
export class ContactService {
  baseUrl: string = 'http://localhost:8085/FinalContactProject/rest/contacts/';
  constructor( private http: HttpClient) { }

  fetchAllContacts(): Observable<Contact[]>
  {
    return this.http.get<Contact[]>(this.baseUrl+"getContacts/");
  }

  fetchAContact(contactName: string): Observable<Contact>
  {
    return this.http.get<Contact>(this.baseUrl+"getContact/"+ contactName);
  }

  addAContact(newCont: Contact): Observable<Contact>{
   
    return this.http.post<Contact>(this.baseUrl+"addContact/", newCont);
  }

  modifyContact(existingcont: Contact): Observable<Contact>{
   
    return this.http.put<Contact>(this.baseUrl+"updateContact/", existingcont);
  }

  deleteContact(contactName: string) : Observable<Contact>{
    return this.http.delete<Contact>(this.baseUrl+"deleteContact/" + contactName);

  }

}
